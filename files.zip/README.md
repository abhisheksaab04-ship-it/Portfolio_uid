# B. Sai Abhishek — Portfolio Website

A personal portfolio website built with HTML5 and CSS3 as part of the 23CSE113 User Interface Design course at Amrita Vishwa Vidyapeetham.

## Website Structure

```
portfolio/
├── index.html       # Homepage — Hero, About, Education, Skills, Projects, Contact
├── about.html       # Detailed About Me page with bio and quick info card
├── skills.html      # Skills breakdown with proficiency bars and tools list
├── projects.html    # Full projects showcase with descriptions and GitHub links
├── styles.css       # Shared stylesheet for all pages
└── README.md        # This file
```

## Pages Overview

- **index.html** — Main landing page with animated hero section, about summary, education timeline, skills grid, project highlights, and contact section.
- **about.html** — Extended bio, story, and an info card with quick personal details.
- **skills.html** — Detailed skills with proficiency levels (Advanced / Intermediate / Beginner) and a tools & technologies section.
- **projects.html** — Full project cards with descriptions, tech tags, and GitHub links.

## Design Details

- **Fonts:** Playfair Display (display), Space Grotesk (body), Space Mono (mono/labels)
- **Color Palette:** Warm parchment background with terracotta/rust accent (#c8502a)
- **Features:** CSS animations, smooth scroll, hover micro-interactions, sticky navbar with glassmorphism, responsive layout with media queries

## Technologies Used

- HTML5 (semantic elements)
- CSS3 (flexbox, grid, custom properties, keyframe animations, media queries)
- Google Fonts

## GitHub Profile

[https://github.com/abhisheksaab04-ship-it](https://github.com/abhisheksaab04-ship-it)

## Author

**B. Sai Abhishek**  
B.Tech Computer Science & Engineering (2025–2029)  
Amrita Vishwa Vidyapeetham, Amritapuri Campus
